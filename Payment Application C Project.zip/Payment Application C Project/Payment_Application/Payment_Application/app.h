#pragma once
#ifndef APP     // Header File Gaurd
#define APP

#include "../Payment_Application/server.h"

void appStart(void);


#endif  // !APP