#include "../Payment_Application/app.h"

int main() {
	appStart();
	//while (getCardHolderNameTest());
	//while (getCardExpiryDateTest());
	//while (getCardPANTest());
	//while (getTransactionDateTest());
	//while (isCardExpiredTest());
	//while (getTransactionAmountTest());
	//while (isBelowMaxAmountTest());
	//while (setMaxAmountTest());
	//while (isValidCardPANTest());
	//while (isValidAccountTest());
	//while (isBlockedAccountTest());
	//while (isAmountAvailableTest());
	//while (saveTransactionTest());
	//while (recieveTransactionDataTest());
	return 0;
}